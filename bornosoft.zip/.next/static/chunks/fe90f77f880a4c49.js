__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/efa3feba159e26d1.js",
  "static/chunks/turbopack-40a3ece7f23ab257.js"
])
