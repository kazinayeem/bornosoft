globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/efa3feba159e26d1.js",
      "static/chunks/turbopack-40a3ece7f23ab257.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/efa3feba159e26d1.js",
      "static/chunks/turbopack-f8410b2edbbab97e.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/02598267019f44b5.js",
    "static/chunks/46d600827f558cc3.js",
    "static/chunks/47f477e3d2ef265b.js",
    "static/chunks/turbopack-96052b39ee52328d.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];