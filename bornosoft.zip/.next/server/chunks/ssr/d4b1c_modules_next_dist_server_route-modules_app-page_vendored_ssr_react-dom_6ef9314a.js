module.exports=[35112,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored["react-ssr"].ReactDOM}];

//# sourceMappingURL=d4b1c_modules_next_dist_server_route-modules_app-page_vendored_ssr_react-dom_6ef9314a.js.map