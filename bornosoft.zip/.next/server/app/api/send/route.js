var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send/route.js")
R.c("server/chunks/[root-of-the-server]__47869f75._.js")
R.c("server/chunks/[root-of-the-server]__a21fb14c._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(88937)
R.m(84988)
module.exports=R.m(84988).exports
